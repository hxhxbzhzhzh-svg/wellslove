/* Wells Love cookie consent: Google Consent Mode v2 + simple banner.
   Loads BEFORE Google Analytics / AdSense on every page.
   - EEA, UK and Switzerland: analytics + ad storage are DENIED until the visitor accepts.
   - Other regions: granted by default, the visitor can still reject at any time.
   NOTE: if you turn on Google's own "Privacy & messaging" (certified CMP) in AdSense,
   set ENABLED = false below so two banners do not appear. */
(function () {
  var ENABLED = true;
  var KEY = 'wl_consent_v1';

  window.dataLayer = window.dataLayer || [];
  function gtag() { dataLayer.push(arguments); }
  if (!window.gtag) { window.gtag = gtag; }

  var DENIED  = { ad_storage: 'denied',  ad_user_data: 'denied',  ad_personalization: 'denied',  analytics_storage: 'denied' };
  var GRANTED = { ad_storage: 'granted', ad_user_data: 'granted', ad_personalization: 'granted', analytics_storage: 'granted' };
  var STRICT_REGIONS = ['AT','BE','BG','HR','CY','CZ','DK','EE','FI','FR','DE','GR','HU','IE','IT','LV','LT','LU','MT','NL','PL','PT','RO','SK','SI','ES','SE','IS','LI','NO','GB','CH'];

  function read() { try { return localStorage.getItem(KEY); } catch (e) { return null; } }
  function write(v) { try { localStorage.setItem(KEY, v); } catch (e) {} }
  function mix(a, b) { var o = {}, k; for (k in a) o[k] = a[k]; for (k in b) o[k] = b[k]; return o; }

  if (!ENABLED) { return; }

  // Region-specific default first, general default second.
  gtag('consent', 'default', mix(DENIED, { region: STRICT_REGIONS, wait_for_update: 500 }));
  gtag('consent', 'default', GRANTED);

  var saved = read();
  if (saved === 'all') { gtag('consent', 'update', GRANTED); }
  else if (saved === 'essential') { gtag('consent', 'update', DENIED); }

  var css =
    '#wl-consent{position:fixed;left:12px;right:12px;bottom:12px;z-index:2147483000;max-width:760px;margin:0 auto;' +
    'background:#16233D;color:#F6F3EC;border-radius:14px;box-shadow:0 10px 40px rgba(0,0,0,.35);padding:18px 20px;' +
    'font:15px/1.5 "IBM Plex Sans",system-ui,-apple-system,Segoe UI,Roboto,sans-serif}' +
    '#wl-consent h2{margin:0 0 6px;font-size:16px;font-weight:600;color:#fff}' +
    '#wl-consent p{margin:0 0 14px;color:rgba(246,243,236,.88)}' +
    '#wl-consent a{color:#F6F3EC;text-decoration:underline}' +
    '#wl-consent .wl-row{display:flex;gap:10px;flex-wrap:wrap}' +
    '#wl-consent button{min-height:44px;padding:10px 20px;border-radius:10px;font:600 15px/1 inherit;cursor:pointer;border:2px solid #F6F3EC;flex:1 1 160px}' +
    '#wl-consent .wl-acc{background:#F6F3EC;color:#16233D}' +
    '#wl-consent .wl-rej{background:transparent;color:#F6F3EC}' +
    '#wl-consent button:focus-visible{outline:3px solid #7FB2FF;outline-offset:2px}';

  function close() { var el = document.getElementById('wl-consent'); if (el && el.parentNode) { el.parentNode.removeChild(el); } }

  function choose(all) {
    write(all ? 'all' : 'essential');
    gtag('consent', 'update', all ? GRANTED : DENIED);
    close();
  }

  function show() {
    if (document.getElementById('wl-consent')) { return; }
    if (!document.getElementById('wl-consent-css')) {
      var st = document.createElement('style'); st.id = 'wl-consent-css'; st.appendChild(document.createTextNode(css));
      document.head.appendChild(st);
    }
    var box = document.createElement('div');
    box.id = 'wl-consent';
    box.setAttribute('role', 'dialog');
    box.setAttribute('aria-label', 'Cookie choices');
    box.innerHTML =
      '<h2>Your cookie choices</h2>' +
      '<p>We use cookies for analytics (Google Analytics) and to show and measure ads (Google AdSense). ' +
      'You can accept all, or reject everything except what the site needs to work. ' +
      'Change your mind any time on the <a href="cookies.html">Cookie Policy</a> page. See our <a href="privacy.html">Privacy Policy</a>.</p>' +
      '<div class="wl-row"><button type="button" class="wl-acc">Accept all</button>' +
      '<button type="button" class="wl-rej">Reject non-essential</button></div>';
    box.querySelector('.wl-acc').addEventListener('click', function () { choose(true); });
    box.querySelector('.wl-rej').addEventListener('click', function () { choose(false); });
    document.body.appendChild(box);
  }

  window.wlOpenConsent = show;

  function init() {
    if (!read()) { show(); }
    var b = document.getElementById('wl-cookie-settings');
    if (b) { b.addEventListener('click', show); }
  }
  if (document.readyState === 'loading') { document.addEventListener('DOMContentLoaded', init); } else { init(); }
})();
