(function(){
var $=function(i){return document.getElementById(i)},W=900,H=600,L=[],A=null,T='brush',z=1,sel=null,SM=null,CS=null,pc=0,U=[],Y=[],N=0,fresh=1,sp=0,dr=null,
D=$('cv'),X=D.getContext('2d'),st=$('st'),sl=$('sl'),
DEF={b:100,c:100,s:100,h:0,u:0,g:0,p:0,i:0},
AS=[['b','Brightness',0,200],['c','Contrast',0,200],['s','Saturation',0,300],['h','Hue',0,360],['u','Blur',0,20],['g','Grayscale',0,100],['p','Sepia',0,100],['i','Invert',0,100]],
TS=[['move','✥','Move (V)','v'],['sel','⬚','Rectangle select (M)','m'],['wand','🪄','Magic wand (W)','w'],['qsel','🖍','Quick selection (Q)','q'],['lasso','➰','Lasso (K)','k'],['clone','🖨','Clone stamp (S): Alt+click sets source','s'],['heal','🩹','Healing brush (J): Alt+click sets source','j'],['brush','🖌','Brush (B)','b'],['erase','◻','Eraser (E)','e'],['fill','🪣','Paint bucket (G)','g'],['grad','◐','Gradient (D)','d'],['eyedrop','💧','Eyedropper (I)','i'],['text','T','Text (T)','t'],['rect','▭','Rectangle (U)','u'],['ellipse','◯','Ellipse (O)','o'],['line','╱','Line (L)','l'],['hand','✋','Hand (H)','h']],
BM=['source-over','multiply','screen','overlay','darken','lighten','color-dodge','color-burn','hard-light','soft-light','difference','exclusion','hue','saturation','color','luminosity'];
function mk(w,h){var c=document.createElement('canvas');c.width=Math.max(1,Math.round(w));c.height=Math.max(1,Math.round(h));return c}
function cp(c){var n=mk(c.width,c.height);n.getContext('2d').drawImage(c,0,0);return n}
function rgb(h){return[1,3,5].map(function(i){return parseInt(h.substr(i,2),16)})}
function hx(n){return('0'+n.toString(16)).slice(-2)}
function fs(a){return JSON.stringify(a)==JSON.stringify(DEF)?'':'brightness('+a.b+'%) contrast('+a.c+'%) saturate('+a.s+'%) hue-rotate('+a.h+'deg) blur('+a.u+'px) grayscale('+a.g+'%) sepia('+a.p+'%) invert('+a.i+'%)'}
function esc(s){return s.replace(/[<>&"]/g,function(c){return'&#'+c.charCodeAt(0)+';'})}
function nl(name,c){var l={c:c||mk(W,H),n:name||'Layer '+(++N),v:1,o:100,b:'source-over',x:0,y:0,a:Object.assign({},DEF)};L.splice(A?L.indexOf(A)+1:L.length,0,l);A=l;return l}
function comp(g){L.forEach(function(l){if(!l.v)return;g.save();g.globalAlpha=l.o/100;g.globalCompositeOperation=l.b;g.filter=fs(l.a)||'none';if(l.adj)adj(g,l);else g.drawImage(mc(l),l.x,l.y);g.restore()})}
function R(){if(D.width!=W||D.height!=H){D.width=W;D.height=H}X.clearRect(0,0,W,H);comp(X);D.style.width=W*z+'px';D.style.height=H*z+'px';sh();ov()}
function sh(){if(!sel){SM=null;sl.style.display='none';return}sl.style.cssText='display:block;left:'+sel.x*z+'px;top:'+sel.y*z+'px;width:'+sel.w*z+'px;height:'+sel.h*z+'px'}
function setZ(v){z=Math.max(.1,Math.min(8,v));$('zl').textContent=Math.round(z*100)+'%';R()}
function fit(){setZ(Math.min((st.clientWidth-40)/W,(st.clientHeight-40)/H,1))}
function LP(){var h='';for(var i=L.length-1;i>=0;i--){var l=L[i];h+='<div class="ly'+(l==A?' on':'')+'" data-i="'+i+'"><button data-e="'+i+'">'+(l.v?'👁':'–')+'</button><span>'+(l.adj?'◑ ':'')+esc(l.n)+(l.m?(l.ed?' ▣':' ◧'):'')+'</span></div>'}$('ll').innerHTML=h;$('lo').value=A.o;$('lb').value=A.b;AD()}
function AD(){AS.forEach(function(s){$('ad-'+s[0]).value=A.a[s[0]]})}
/* history */
function sn(){return{W:W,H:H,A:L.indexOf(A),L:L.map(function(l){return Object.assign({},l,{c:cp(l.c),m:l.m&&!l.ed?cp(l.m):null,cc:l.cc?cp(l.cc):null,a:Object.assign({},l.a)})})}}
function P(){pc++;U.push(sn());if(U.length>30)U.shift();Y=[];fresh=0}
function rs(s){W=s.W;H=s.H;L=s.L;L.forEach(function(l){if(l.ed)l.m=l.c});A=L[s.A]||L[0];sel=null;R();LP()}
function un(){if(U.length){Y.push(sn());rs(U.pop())}}
function re(){if(Y.length){U.push(sn());rs(Y.pop())}}
function init(w,h){W=w;H=h;L=[];A=null;N=0;U=[];Y=[];sel=null;var l=nl('Background');var g=l.c.getContext('2d');g.fillStyle='#fff';g.fillRect(0,0,W,H);fresh=1;fit();LP()}
/* painting */
function G(){var g=A.c.getContext('2d');g.save();if(sel){g.beginPath();g.rect(sel.x-A.x,sel.y-A.y,sel.w,sel.h);g.clip()}return g}
function cmp(){var g=A.c.getContext('2d');g.save();g.globalCompositeOperation='source-over';g.clearRect(0,0,A.c.width,A.c.height);g.drawImage(dr.base,0,0);if(sel){g.beginPath();g.rect(sel.x-A.x,sel.y-A.y,sel.w,sel.h);g.clip()}g.globalAlpha=$('op2').value/100;g.globalCompositeOperation=T=='erase'?'destination-out':'source-over';g.drawImage(dr.sc,0,0);g.restore()}
function stamp(a,b){var g=dr.sc.getContext('2d'),s=+$('sz').value,hd=+$('hd').value/100,c=rgb(T=='erase'?'#000000':$('fg').value),r=s/2,dx=b[0]-a[0],dy=b[1]-a[1],n=Math.max(1,Math.ceil(Math.hypot(dx,dy)/Math.max(1,s*.12)));
for(var i=1;i<=n;i++){var x=a[0]+dx*i/n-A.x,y=a[1]+dy*i/n-A.y;g.beginPath();g.arc(x,y,r,0,7);if(hd>=.99)g.fillStyle='rgb('+c+')';else{var q=g.createRadialGradient(x,y,r*hd,x,y,r);q.addColorStop(0,'rgba('+c+',1)');q.addColorStop(1,'rgba('+c+',0)');g.fillStyle=q}g.fill()}}
function shp(p){var g=dr.sc.getContext('2d'),a=dr.p,x=a[0]-A.x,y=a[1]-A.y,w=p[0]-a[0],h=p[1]-a[1];g.clearRect(0,0,dr.sc.width,dr.sc.height);g.fillStyle=g.strokeStyle=$('fg').value;g.lineWidth=+$('sz').value;g.lineCap='round';g.beginPath();
if(T=='line'){g.moveTo(x,y);g.lineTo(x+w,y+h);g.stroke()}else{if(T=='rect')g.rect(x,y,w,h);else g.ellipse(x+w/2,y+h/2,Math.abs(w/2),Math.abs(h/2),0,0,7);$('fl').checked?g.fill():g.stroke()}}
function grd(p){var g=dr.sc.getContext('2d'),a=dr.p,q=g.createLinearGradient(a[0]-A.x,a[1]-A.y,p[0]-A.x,p[1]-A.y);q.addColorStop(0,$('fg').value);q.addColorStop(1,$('bg').value);g.fillStyle=q;g.fillRect(0,0,dr.sc.width,dr.sc.height)}
function flood(x,y){var c=A.c,w=c.width,h=c.height;x=Math.round(x-A.x);y=Math.round(y-A.y);if(x<0||y<0||x>=w||y>=h)return;var g=c.getContext('2d'),im=g.getImageData(0,0,w,h),d=im.data,i=(y*w+x)*4,t=[d[i],d[i+1],d[i+2],d[i+3]],f=rgb($('fg').value),lim=$('tol').value*10.2,o=$('op2').value/100,s=[y*w+x],seen=new Uint8Array(w*h),k,j,X0,Y0;
var sx=sel?sel.x-A.x:0,sy=sel?sel.y-A.y:0,ex=sel?sx+sel.w:w,ey=sel?sy+sel.h:h;
while(s.length){k=s.pop();if(seen[k])continue;X0=k%w;Y0=(k-X0)/w;if(X0<sx||X0>=ex||Y0<sy||Y0>=ey)continue;j=k*4;if(Math.abs(d[j]-t[0])+Math.abs(d[j+1]-t[1])+Math.abs(d[j+2]-t[2])+Math.abs(d[j+3]-t[3])>lim)continue;seen[k]=1;
d[j]=d[j]*(1-o)+f[0]*o;d[j+1]=d[j+1]*(1-o)+f[1]*o;d[j+2]=d[j+2]*(1-o)+f[2]*o;d[j+3]=d[j+3]*(1-o)+255*o;
if(X0>0)s.push(k-1);if(X0<w-1)s.push(k+1);if(Y0>0)s.push(k-w);if(Y0<h-1)s.push(k+w)}
g.putImageData(im,0,0)}
function pt(e){var r=D.getBoundingClientRect();return[(e.clientX-r.left)/z,(e.clientY-r.top)/z]}
st.addEventListener('pointerdown',function(e){
if(e.button==1||T=='hand'||sp){dr={pan:1,sx:e.clientX,sy:e.clientY,l:st.scrollLeft,t:st.scrollTop};st.setPointerCapture(e.pointerId);return}
if(!A||e.button)return;var p=pt(e);
if(T=='eyedrop'){var d=X.getImageData(Math.max(0,Math.min(W-1,p[0]|0)),Math.max(0,Math.min(H-1,p[1]|0)),1,1).data;$('fg').value='#'+hx(d[0])+hx(d[1])+hx(d[2]);return}
if(T=='sel'){dr={p:p,sel:1};sel=null;sh();st.setPointerCapture(e.pointerId);return}
if(T=='text'){var t=prompt('Text:');if(t){P();var g=G();g.fillStyle=$('fg').value;g.globalAlpha=$('op2').value/100;g.font=$('ts').value+'px '+$('tf').value;g.textBaseline='top';t.split('\n').forEach(function(s,i){g.fillText(s,p[0]-A.x,p[1]-A.y+i*$('ts').value*1.2)});g.restore();mfix();R()}return}
if(T=='wand'){setSel(wand(p[0],p[1]),e);return}
if(T=='qsel'){setSel(wand(p[0],p[1]),e);dr={qs:1,l:p};st.setPointerCapture(e.pointerId);return}
if(T=='lasso'){dr={ls:1,pts:[p],e:{shiftKey:e.shiftKey,altKey:e.altKey}};st.setPointerCapture(e.pointerId);return}
if((T=='clone'||T=='heal')&&e.altKey){CS=p;return}
if((T=='clone'||T=='heal')&&!CS){alert('Alt+click on the image to set the source point first.');return}
P();
if(T=='clone'||T=='heal'){st.setPointerCapture(e.pointerId);dr={p:p,l:p,base:cp(A.c),sc:mk(A.c.width,A.c.height),off:[CS[0]-p[0],CS[1]-p[1]]};cl(p,p);cmp();R();return}
if(T=='fill'){flood(p[0],p[1]);mfix();R();return}
st.setPointerCapture(e.pointerId);
if(T=='move'){dr={p:p,x:A.x,y:A.y};return}
dr={p:p,l:p,base:cp(A.c),sc:mk(A.c.width,A.c.height)};
if(T=='brush'||T=='erase'){stamp(p,p);cmp();R()}
});
st.addEventListener('pointermove',function(e){if(!dr)return;
if(dr.pan){st.scrollLeft=dr.l-(e.clientX-dr.sx);st.scrollTop=dr.t-(e.clientY-dr.sy);return}
var p=pt(e);
if(dr.ls){dr.pts.push(p);R();lsDraw();return}
if(dr.qs){if(Math.hypot(p[0]-dr.l[0],p[1]-dr.l[1])>5/z){dr.l=p;setSel(wand(p[0],p[1]),{shiftKey:1})}return}
if(dr.sel){var x=Math.max(0,Math.min(dr.p[0],p[0])),y=Math.max(0,Math.min(dr.p[1],p[1])),x2=Math.min(W,Math.max(dr.p[0],p[0])),y2=Math.min(H,Math.max(dr.p[1],p[1]));sel={x:Math.round(x),y:Math.round(y),w:Math.round(x2-x),h:Math.round(y2-y)};sh();return}
if(T=='move'){A.x=Math.round(dr.x+p[0]-dr.p[0]);A.y=Math.round(dr.y+p[1]-dr.p[1]);R();return}
if(T=='brush'||T=='erase'){stamp(dr.l,p);dr.l=p}else if(T=='clone'||T=='heal'){cl(dr.l,p);dr.l=p}else if(T=='grad')grd(p);else shp(p);
cmp();R()});
function up(){if(dr&&dr.ls)lsEnd();if(dr&&dr.base&&T!='move'&&!dr.sel){mfix();R()}if(dr&&dr.sel&&sel&&(sel.w<2||sel.h<2)){sel=null;sh()}dr=null}
st.addEventListener('pointerup',up);st.addEventListener('pointercancel',up);
st.addEventListener('wheel',function(e){if(e.ctrlKey||e.metaKey){e.preventDefault();setZ(z*(e.deltaY<0?1.1:.9))}},{passive:false});
/* adjustments */
function bake(){P();var n=mk(A.c.width,A.c.height),g=n.getContext('2d');g.filter=fs(A.a)||'none';g.drawImage(A.c,0,0);A.c=n;A.a=Object.assign({},DEF);AD();R()}
/* filters */
function conv(k,dv,of){P();var c=A.c,w=c.width,h=c.height,g=c.getContext('2d'),s=g.getImageData(0,0,w,h),o=g.createImageData(w,h),a=s.data,b=o.data,x,y,i,ch,v,j,xx,yy;
for(y=0;y<h;y++)for(x=0;x<w;x++){i=(y*w+x)*4;for(ch=0;ch<3;ch++){v=0;for(j=0;j<9;j++){xx=Math.min(w-1,Math.max(0,x+j%3-1));yy=Math.min(h-1,Math.max(0,y+(j/3|0)-1));v+=a[(yy*w+xx)*4+ch]*k[j]}b[i+ch]=v/dv+of}b[i+3]=a[i+3]}
g.putImageData(o,0,0);R()}
function area(){return sel?[sel.x-A.x,sel.y-A.y,sel.w,sel.h]:[0,0,A.c.width,A.c.height]}
function rot(d){P();bk();var c=A.c,w=c.width,h=c.height,r=d*Math.PI/180,s=Math.abs(Math.sin(r)),k=Math.abs(Math.cos(r)),nw=Math.ceil(w*k+h*s),nh=Math.ceil(w*s+h*k),n=mk(nw,nh),g=n.getContext('2d');g.translate(nw/2,nh/2);g.rotate(r);g.drawImage(c,-w/2,-h/2);A.x=Math.round(A.x+(w-nw)/2);A.y=Math.round(A.y+(h-nh)/2);A.c=n;R()}
function flip(hz){P();bk();var c=A.c,n=mk(c.width,c.height),g=n.getContext('2d');g.translate(hz?c.width:0,hz?0:c.height);g.scale(hz?-1:1,hz?1:-1);g.drawImage(c,0,0);A.c=n;R()}
var OPS={
crop:function(){if(!sel)return alert('Make a selection with the Select tool first.');P();var s=sel;L.forEach(function(l){l.x-=s.x;l.y-=s.y});W=s.w;H=s.h;sel=null;fit()},
cvs:function(){var v=(prompt('New canvas size (width x height):',W+'x'+H)||'').split(/x|×/i),w=+v[0],h=+v[1];if(w>0&&h>0&&w<=8000&&h<=8000){P();W=w;H=h;fit()}},
rsz:function(){var w=+prompt('New width in pixels (height keeps proportions):',W);if(!(w>0&&w<=8000))return;P();var f=w/W;L.forEach(function(l){var n=mk(l.c.width*f,l.c.height*f);n.getContext('2d').drawImage(l.c,0,0,n.width,n.height);if(l.m){var q=mk(n.width,n.height);q.getContext('2d').drawImage(l.m,0,0,n.width,n.height);l.m=q}l.c=n;l.x=Math.round(l.x*f);l.y=Math.round(l.y*f)});W=Math.round(W*f);H=Math.round(H*f);sel=null;fit()},
fh:function(){flip(1)},fv:function(){flip(0)},r90:function(){rot(90)},r270:function(){rot(-90)},
rot:function(){var a=parseFloat(prompt('Angle in degrees (clockwise):','15'));if(a)rot(a)},
sharp:function(){conv([0,-1,0,-1,5,-1,0,-1,0],1,0)},emb:function(){conv([-2,-1,0,-1,1,1,0,1,2],1,128)},edge:function(){conv([-1,-1,-1,-1,8,-1,-1,-1,-1],1,0)},
pix:function(){var n=+prompt('Block size in pixels:','12');if(!(n>1))return;P();var a=area(),c=A.c,g=c.getContext('2d'),t=mk(a[2]/n,a[3]/n),tg=t.getContext('2d');tg.drawImage(c,a[0],a[1],a[2],a[3],0,0,t.width,t.height);g.save();g.imageSmoothingEnabled=false;g.clearRect(a[0],a[1],a[2],a[3]);g.drawImage(t,0,0,t.width,t.height,a[0],a[1],a[2],a[3]);g.restore();R()},
noi:function(){P();var a=area(),g=A.c.getContext('2d'),im=g.getImageData(a[0],a[1],a[2],a[3]),d=im.data;for(var i=0;i<d.length;i+=4){var v=(Math.random()-.5)*60;d[i]+=v;d[i+1]+=v;d[i+2]+=v}g.putImageData(im,a[0],a[1]);R()},
vig:function(){P();var a=area(),g=A.c.getContext('2d'),cx=a[0]+a[2]/2,cy=a[1]+a[3]/2,r=Math.hypot(a[2],a[3])/2,q=g.createRadialGradient(cx,cy,r*.35,cx,cy,r);q.addColorStop(0,'rgba(0,0,0,0)');q.addColorStop(1,'rgba(0,0,0,.75)');g.save();g.globalCompositeOperation='source-atop';g.fillStyle=q;g.fillRect(a[0],a[1],a[2],a[3]);g.restore();R()},
fillsel:function(){P();var a=area(),g=A.c.getContext('2d');g.fillStyle=$('fg').value;g.globalAlpha=$('op2').value/100;g.fillRect(a[0],a[1],a[2],a[3]);R()},
clr:function(){P();var a=area();A.c.getContext('2d').clearRect(a[0],a[1],a[2],a[3]);R()}};
['sharp','emb','edge','pix','noi','vig','fillsel','clr'].forEach(function(k){var f=OPS[k];OPS[k]=function(){var c=pc;f();if(pc>c){mfix();R()}}});
['mi','mf'].forEach(function(i){$(i).onchange=function(){var v=this.value;this.selectedIndex=0;if(OPS[v])OPS[v]()}});
/* files */
function imp(f){if(!f||!/^image\//.test(f.type))return;var u=URL.createObjectURL(f),im=new Image();im.onload=function(){var f0=fresh;P();var c=mk(im.width,im.height);c.getContext('2d').drawImage(im,0,0);if(f0){W=c.width;H=c.height;L=[];A=null;sel=null}nl(f.name.replace(/\.[^.]+$/,'')||'Image',c);fresh=0;if(f0)fit();else R();LP();URL.revokeObjectURL(u)};im.onerror=function(){alert('Could not open this image.')};im.src=u}
$('op').onclick=function(){$('fi').click()};$('fi').onchange=function(){[].forEach.call(this.files,imp);this.value=''};
st.addEventListener('dragover',function(e){e.preventDefault()});st.addEventListener('drop',function(e){e.preventDefault();[].forEach.call(e.dataTransfer.files,imp)});
document.addEventListener('paste',function(e){[].forEach.call((e.clipboardData||{}).files||[],imp)});
$('nw').onclick=function(){var v=(prompt('New document (width x height):','1200x800')||'').split(/x|×/i),w=+v[0],h=+v[1];if(w>0&&h>0&&w<=8000&&h<=8000)init(w,h)};
$('ex').onclick=function(){var t=$('ef').value,c=mk(W,H),g=c.getContext('2d');if(t!='image/png'){g.fillStyle='#fff';g.fillRect(0,0,W,H)}comp(g);c.toBlob(function(b){var a=document.createElement('a');a.href=URL.createObjectURL(b);a.download='wellslove-edit.'+t.split('/')[1].replace('jpeg','jpg');a.click()},t,Math.min(1,Math.max(.1,$('eq').value/100)))};
/* UI wiring */
$('un').onclick=un;$('re').onclick=re;$('zi').onclick=function(){setZ(z*1.25)};$('zo').onclick=function(){setZ(z/1.25)};$('zf').onclick=fit;
$('sw').onclick=function(){var a=$('fg').value;$('fg').value=$('bg').value;$('bg').value=a};
var tl=$('tl');TS.forEach(function(t){var b=document.createElement('button');b.textContent=t[1];b.title=t[2];b.dataset.t=t[0];tl.appendChild(b)});
function setT(t){T=t;[].forEach.call(tl.children,function(b){b.classList.toggle('on',b.dataset.t==t)});D.style.cursor=t=='hand'?'grab':t=='move'?'move':'crosshair'}
tl.onclick=function(e){if(e.target.dataset.t)setT(e.target.dataset.t)};setT('brush');
var ad=$('ad');AS.forEach(function(s){var r=document.createElement('div');r.className='rw';r.innerHTML='<label>'+s[1]+'</label><input type="range" id="ad-'+s[0]+'" min="'+s[2]+'" max="'+s[3]+'" value="'+DEF[s[0]]+'">';r.lastChild.oninput=function(){A.a[s[0]]=+this.value;R()};ad.appendChild(r)});
$('aa').onclick=bake;$('ar').onclick=function(){A.a=Object.assign({},DEF);AD();R()};
BM.forEach(function(m){var o=document.createElement('option');o.value=m;o.textContent=m=='source-over'?'normal':m.replace('-',' ');$('lb').appendChild(o)});
$('lb').onchange=function(){A.b=this.value;R()};$('lo').oninput=function(){A.o=+this.value;R()};
$('ll').onclick=function(e){var t=e.target;if(t.dataset.e!=null){var l=L[+t.dataset.e];l.v=!l.v}else{var r=t.closest('.ly');if(!r)return;xm();A=L[+r.dataset.i]}LP();R()};
$('ll').ondblclick=function(e){var r=e.target.closest('.ly');if(!r)return;var l=L[+r.dataset.i];if(l.adj){A=l;dlg(l);return}var n=prompt('Layer name:',l.n);if(n){l.n=n;LP()}};
$('la').onclick=function(){P();nl();LP()};
$('ld').onclick=function(){xm();P();var l=Object.assign({},A,{c:cp(A.c),m:A.m?cp(A.m):null,a:Object.assign({},A.a),n:A.n+' copy'});L.splice(L.indexOf(A)+1,0,l);A=l;LP();R()};
$('lx').onclick=function(){if(L.length<2)return;P();var i=L.indexOf(A);L.splice(i,1);A=L[Math.max(0,i-1)];LP();R()};
$('lu').onclick=function(){var i=L.indexOf(A);if(i<L.length-1){P();L.splice(i,1);L.splice(i+1,0,A);LP();R()}};
$('lw').onclick=function(){var i=L.indexOf(A);if(i>0){P();L.splice(i,1);L.splice(i-1,0,A);LP();R()}};
$('lm').onclick=function(){xm();var i=L.indexOf(A);if(i<1||A.adj||L[i-1].adj){if(A.adj)alert('Adjustment layers cannot be merged down.');return}P();var B=L[i-1];if(B.m){B.c=mc(B);B.m=null}var g=B.c.getContext('2d');g.save();g.globalAlpha=A.o/100;g.globalCompositeOperation=A.b;g.filter=fs(A.a)||'none';g.drawImage(mc(A),A.x-B.x,A.y-B.y);g.restore();L.splice(i,1);A=B;LP();R()};
document.addEventListener('keydown',function(e){var t=e.target.tagName;if(t=='INPUT'||t=='SELECT'||t=='TEXTAREA')return;var k=e.key.toLowerCase(),m=e.ctrlKey||e.metaKey;
if(m&&e.shiftKey&&k=='i'){e.preventDefault();SO.inv();return}if(k==' '){sp=1;e.preventDefault();return}
if(m&&k=='z'){e.preventDefault();e.shiftKey?re():un();return}if(m&&k=='y'){e.preventDefault();re();return}
if(m&&k=='a'){e.preventDefault();SM=null;sel={x:0,y:0,w:W,h:H};sh();return}if(m&&k=='d'){e.preventDefault();sel=null;sh();return}
if(k=='delete'||k=='backspace'){e.preventDefault();OPS.clr();return}
if(k=='['){$('sz').value=Math.max(1,$('sz').value-5);return}if(k==']'){$('sz').value=+$('sz').value+5;return}
if(!m)TS.forEach(function(s){if(s[3]==k)setT(s[0])})});
document.addEventListener('keyup',function(e){if(e.key==' ')sp=0});
window.addEventListener('beforeunload',function(e){if(U.length){e.preventDefault();e.returnValue=''}});
/* ===== pro extensions ===== */
function ov(){if(SM){var t=cp(SM),g=t.getContext('2d');g.globalCompositeOperation='source-in';g.fillStyle='rgba(30,120,255,.35)';g.fillRect(0,0,W,H);X.drawImage(t,0,0)}}
function mc(l){var c=l.ed?l.cc:l.c,m=l.ed?l.c:l.m;if(!m)return c;var t=cp(c),g=t.getContext('2d');g.globalCompositeOperation='destination-in';g.drawImage(m,0,0);return t}
function xm(){if(A&&A.ed){A.c=A.cc;A.cc=null;A.ed=0}}
function bk(){xm();if(A.m&&!A.adj){A.c=mc(A);A.m=null}}
function ix(v){return Math.max(0,Math.min(255,Math.round(v)))}
function adj(g,l){var w=g.canvas.width,h=g.canvas.height,im=g.getImageData(0,0,w,h),d=im.data,T0=l.adj.t,m=l.ed?l.c:l.m;for(var i=0;i<d.length;i+=4){d[i]=T0[0][d[i]];d[i+1]=T0[1][d[i+1]];d[i+2]=T0[2][d[i+2]]}var t=mk(w,h),tg=t.getContext('2d');tg.putImageData(im,0,0);if(m){tg.globalCompositeOperation='destination-in';tg.drawImage(m,0,0)}g.drawImage(t,0,0)}
function cv256(p){p=p.slice().sort(function(a,b){return a[0]-b[0]});var n=p.length,m=[],d=[],o=[],i,k;for(i=0;i<n-1;i++)d[i]=(p[i+1][1]-p[i][1])/Math.max(1e-6,p[i+1][0]-p[i][0]);m[0]=d[0];m[n-1]=d[n-2];for(i=1;i<n-1;i++)m[i]=d[i-1]*d[i]<=0?0:(d[i-1]+d[i])/2;for(i=0;i<n-1;i++){if(d[i]==0){m[i]=m[i+1]=0}else{var a=m[i]/d[i],b=m[i+1]/d[i],q=a*a+b*b;if(q>9){var t=3/Math.sqrt(q);m[i]=t*a*d[i];m[i+1]=t*b*d[i]}}}
for(k=0;k<256;k++){if(k<=p[0][0]){o[k]=p[0][1];continue}if(k>=p[n-1][0]){o[k]=p[n-1][1];continue}for(i=0;i<n-2&&k>p[i+1][0];i++);var h=p[i+1][0]-p[i][0],u=(k-p[i][0])/h,u2=u*u,u3=u2*u;o[k]=(2*u3-3*u2+1)*p[i][1]+(u3-2*u2+u)*h*m[i]+(-2*u3+3*u2)*p[i+1][1]+(u3-u2)*h*m[i+1]}return o}
function mkLut(S){var v=S.lv,c0=cv256(S.p[0]);return[1,2,3].map(function(ch){var cc=cv256(S.p[ch]),u=new Uint8ClampedArray(256);for(var k=0;k<256;k++){var x=Math.pow(Math.max(0,Math.min(1,(k-v[0])/Math.max(1,v[2]-v[0]))),1/v[1])*(v[4]-v[3])+v[3];u[k]=cc[ix(c0[ix(x)])]}return u})}
function dlg(ed){xm();P();var S,l;if(ed){l=ed;S=JSON.parse(JSON.stringify(ed.adj.S))}else{S={p:[0,1,2,3].map(function(){return[[0,0],[255,255]]}),lv:[0,1,255,0,255]};l=nl('Levels / Curves');l.adj={S:S,t:mkLut(S)};if(sel)l.m=selMask()}
var ch=0,o=document.createElement('div');o.style.cssText='position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:99;display:flex;align-items:center;justify-content:center';
o.innerHTML='<div style="background:#fff;padding:14px;border-radius:4px;width:300px;font-size:13px"><b>Levels / Curves</b><div class="rw" style="margin-top:8px"><label>Channel</label><select id="cC"><option>RGB</option><option>Red</option><option>Green</option><option>Blue</option></select></div><canvas id="cK" width="256" height="256" style="border:1px solid #999;cursor:crosshair;display:block;margin:6px auto;touch-action:none"></canvas><div id="cL"></div><div style="text-align:right;margin-top:8px"><button class="btn" id="cX">Cancel</button> <button class="btn d" id="cO">OK</button></div></div>';document.body.appendChild(o);
var K=o.querySelector('#cK'),g=K.getContext('2d'),dg=null;
function ap(){l.adj={S:S,t:mkLut(S)};R();dw()}
function dw(){g.clearRect(0,0,256,256);g.strokeStyle='#ddd';for(var i=64;i<256;i+=64){g.beginPath();g.moveTo(i,0);g.lineTo(i,256);g.moveTo(0,i);g.lineTo(256,i);g.stroke()}var c=cv256(S.p[ch]);g.strokeStyle=['#000','#d00','#0a0','#00d'][ch];g.beginPath();for(var k=0;k<256;k++)g.lineTo(k,255-ix(c[k]));g.stroke();S.p[ch].forEach(function(q){g.fillStyle='#fff';g.strokeRect(q[0]-3,252-q[1],6,6);g.fillRect(q[0]-3,252-q[1],6,6)})}
function np(e){var r=K.getBoundingClientRect();return[ix(e.clientX-r.left),ix(255-(e.clientY-r.top))]}
function nr(q){var P0=S.p[ch],b=-1,bd=99;P0.forEach(function(a,i){var d=Math.hypot(a[0]-q[0],a[1]-q[1]);if(d<bd){bd=d;b=i}});return bd<10?b:-1}
K.onpointerdown=function(e){var q=np(e),i=nr(q);if(i<0){S.p[ch].push(q);i=S.p[ch].length-1}dg=i;K.setPointerCapture(e.pointerId);ap()};
K.onpointermove=function(e){if(dg==null)return;S.p[ch][dg]=np(e);ap()};K.onpointerup=function(){dg=null};
K.ondblclick=function(e){var i=nr(np(e));if(i>=0&&S.p[ch].length>2){S.p[ch].splice(i,1);ap()}};
o.querySelector('#cC').onchange=function(){ch=this.selectedIndex;dw()};
[['Input black',0,254,1],['Gamma',.1,3,.01],['Input white',1,255,1],['Output black',0,255,1],['Output white',0,255,1]].forEach(function(a,i){var r=document.createElement('div');r.className='rw';r.innerHTML='<label>'+a[0]+'</label><input type="range" min="'+a[1]+'" max="'+a[2]+'" step="'+a[3]+'" value="'+S.lv[i]+'">';r.lastChild.oninput=function(){S.lv[i]=+this.value;ap()};o.querySelector('#cL').appendChild(r)});
o.querySelector('#cO').onclick=function(){o.remove();LP();R()};o.querySelector('#cX').onclick=function(){o.remove();un()};ap();LP()}
function selMask(){var m=mk(W,H),g=m.getContext('2d');if(SM)g.drawImage(SM,0,0);else if(sel){g.fillStyle='#000';g.fillRect(sel.x,sel.y,sel.w,sel.h)}return m}
function fm(m){var d=m.getContext('2d').getImageData(0,0,W,H).data,x0=W,y0=H,x1=-1,y1=-1,x,y;for(y=0;y<H;y++)for(x=0;x<W;x++)if(d[(y*W+x)*4+3]>8){if(x<x0)x0=x;if(x>x1)x1=x;if(y<y0)y0=y;if(y>y1)y1=y}if(x1<0){SM=null;sel=null;sh();R();return}SM=m;sel={x:x0,y:y0,w:x1-x0+1,h:y1-y0+1};sh();R()}
function setSel(m,e){var has=SM||sel,o=e&&e.shiftKey&&has?'source-over':e&&e.altKey&&has?'destination-out':null,b=m;if(o){b=selMask();var g=b.getContext('2d');g.globalCompositeOperation=o;g.drawImage(m,0,0)}fm(b)}
function wand(x,y){var o=mk(W,H);x=Math.round(x);y=Math.round(y);if(x<0||y<0||x>=W||y>=H)return o;var t=mk(W,H);comp(t.getContext('2d'));var d=t.getContext('2d').getImageData(0,0,W,H).data,og=o.getContext('2d'),oi=og.createImageData(W,H),od=oi.data,seen=new Uint8Array(W*H),s=[y*W+x],i=(y*W+x)*4,lim=$('tol').value*10.2,k,j,xx,yy,r=d[i],g=d[i+1],b=d[i+2],a=d[i+3];while(s.length){k=s.pop();if(seen[k])continue;seen[k]=1;j=k*4;if(Math.abs(d[j]-r)+Math.abs(d[j+1]-g)+Math.abs(d[j+2]-b)+Math.abs(d[j+3]-a)>lim)continue;od[j+3]=255;xx=k%W;yy=(k-xx)/W;if(xx>0)s.push(k-1);if(xx<W-1)s.push(k+1);if(yy>0)s.push(k-W);if(yy<H-1)s.push(k+W)}og.putImageData(oi,0,0);return o}
function lsDraw(){var p=dr.pts;X.save();X.lineWidth=1/z;[['#fff',0],['#000',4/z]].forEach(function(c){X.strokeStyle=c[0];X.setLineDash([4/z,4/z]);X.lineDashOffset=c[1];X.beginPath();p.forEach(function(q,i){i?X.lineTo(q[0],q[1]):X.moveTo(q[0],q[1])});X.stroke()});X.restore()}
function lsEnd(){var p=dr.pts;if(p.length>2){var m=mk(W,H),g=m.getContext('2d');g.fillStyle='#000';g.beginPath();p.forEach(function(q,i){i?g.lineTo(q[0],q[1]):g.moveTo(q[0],q[1])});g.closePath();g.fill();setSel(m,dr.e)}else R()}
function mfix(){if(!SM||!A||A.ed)return;var s=U[U.length-1],o=s&&s.L[L.indexOf(A)];if(!o||o.c.width!=A.c.width||o.c.height!=A.c.height)return;var n=cp(A.c),g=n.getContext('2d');g.globalCompositeOperation='destination-in';g.drawImage(SM,-A.x,-A.y);var h=A.c.getContext('2d');h.save();h.globalCompositeOperation='copy';h.drawImage(o.c,0,0);h.globalCompositeOperation='destination-out';h.drawImage(SM,-A.x,-A.y);h.globalCompositeOperation='source-over';h.drawImage(n,0,0);h.restore()}
function mn(c,x,y,r){var t=mk(1,1),g=t.getContext('2d');g.drawImage(c,x-r,y-r,2*r,2*r,0,0,1,1);return g.getImageData(0,0,1,1).data}
function hl(t,B,px,py,sx,sy,r){var a=mn(B,sx,sy,r),b=mn(B,px,py,r),g=t.getContext('2d'),im=g.getImageData(0,0,t.width,t.height),d=im.data;for(var i=0;i<d.length;i+=4)for(var c=0;c<3;c++)d[i+c]=ix(d[i+c]+b[c]-a[c]);g.putImageData(im,0,0)}
function cl(a,b){var s=Math.max(2,+$('sz').value),hd=+$('hd').value/100,g=dr.sc.getContext('2d'),dx=b[0]-a[0],dy=b[1]-a[1],n=Math.max(1,Math.ceil(Math.hypot(dx,dy)/Math.max(1,s*.15)));for(var i=1;i<=n;i++){var x=a[0]+dx*i/n,y=a[1]+dy*i/n,px=x-A.x,py=y-A.y,sx=px+dr.off[0],sy=py+dr.off[1],r=s/2,t=mk(s,s),tg=t.getContext('2d');tg.drawImage(dr.base,-(sx-r),-(sy-r));if(T=='heal')hl(t,dr.base,px,py,sx,sy,r);tg.globalCompositeOperation='destination-in';var q=tg.createRadialGradient(r,r,r*hd*.9,r,r,r);q.addColorStop(0,'#000');q.addColorStop(1,'rgba(0,0,0,0)');tg.fillStyle=q;tg.fillRect(0,0,t.width,t.height);g.drawImage(t,px-r,py-r)}}
var SO={inv:function(){var m=mk(W,H),g=m.getContext('2d');g.fillStyle='#000';g.fillRect(0,0,W,H);g.globalCompositeOperation='destination-out';g.drawImage(selMask(),0,0);fm(m)},
fea:function(){if(!sel)return alert('Make a selection first.');var n=+prompt('Feather radius (px):','8');if(!(n>0))return;var m=mk(W,H),g=m.getContext('2d');g.filter='blur('+n+'px)';g.drawImage(selMask(),0,0);fm(m)}};
var SP=document.querySelector('#pe .pb .sp');
function mkb(t,f,c){var b=document.createElement('button');b.className='btn '+(c||'');b.textContent=t;b.onclick=f;SP.parentNode.insertBefore(b,SP)}
var ms=document.createElement('select');ms.innerHTML='<option>Select ▾</option><option value="inv">Invert selection (Ctrl+Shift+I)</option><option value="fea">Feather selection…</option>';ms.onchange=function(){var v=this.value;this.selectedIndex=0;if(SO[v])SO[v]()};SP.parentNode.insertBefore(ms,SP);
function img(u){return new Promise(function(r){if(!u)return r(null);var i=new Image();i.onload=function(){var c=mk(i.width,i.height);c.getContext('2d').drawImage(i,0,0);r(c)};i.src=u})}
mkb('Save project',function(){xm();LP();var o={v:1,W:W,H:H,A:L.indexOf(A),L:L.map(function(l){return{n:l.n,v:l.v,o:l.o,b:l.b,x:l.x,y:l.y,a:l.a,adj:l.adj?{S:l.adj.S}:null,c:l.c.toDataURL(),m:l.m?l.m.toDataURL():null}})},a=document.createElement('a');a.href=URL.createObjectURL(new Blob([JSON.stringify(o)],{type:'application/json'}));a.download='project.wlp';a.click()});
var pf=document.createElement('input');pf.type='file';pf.accept='.wlp,.json';pf.hidden=true;document.body.appendChild(pf);
mkb('Open project',function(){pf.click()});
pf.onchange=function(){var f=this.files[0];this.value='';if(!f)return;var fr=new FileReader();fr.onload=function(){var o;try{o=JSON.parse(fr.result);if(!o.L)throw 0}catch(e){return alert('Not a valid project file.')}Promise.all(o.L.map(function(l){return Promise.all([img(l.c),img(l.m)])})).then(function(r){xm();P();W=o.W;H=o.H;L=o.L.map(function(l,i){return{n:l.n,v:l.v,o:l.o,b:l.b,x:l.x,y:l.y,a:l.a,c:r[i][0],m:r[i][1],adj:l.adj?{S:l.adj.S,t:mkLut(l.adj.S)}:null}});N=L.length;A=L[o.A]||L[0];sel=null;fresh=0;fit();LP()})};fr.readAsText(f)};
$('ll').insertAdjacentHTML('afterend','<div class="mb" id="mkb"><button data-k="add">+ Mask</button><button data-k="ed">Edit mask / layer</button><button data-k="inv">Invert mask</button><button data-k="app">Apply mask</button><button data-k="del">Delete mask</button><button data-k="adj">+ Levels / Curves layer</button></div>');
$('mkb').onclick=function(e){var k=e.target.dataset.k;if(!k)return;if(k=='adj')return dlg();if(k=='add'){if(A.m)return;xm();P();var m=mk(A.adj?W:A.c.width,A.adj?H:A.c.height),g=m.getContext('2d');g.fillStyle='#000';g.fillRect(0,0,m.width,m.height);if(sel){g.clearRect(0,0,m.width,m.height);g.drawImage(selMask(),-A.x,-A.y)}A.m=m}
else if(!A.m)return alert('This layer has no mask. Click "+ Mask" first.');
else if(k=='ed'){if(A.ed)xm();else{A.cc=A.c;A.c=A.m;A.ed=1}}
else{xm();P();if(k=='inv'){var n=mk(A.m.width,A.m.height),q=n.getContext('2d');q.fillStyle='#000';q.fillRect(0,0,n.width,n.height);q.globalCompositeOperation='destination-out';q.drawImage(A.m,0,0);A.m=n}else{if(k=='app'&&!A.adj)A.c=mc(A);A.m=null}}
LP();R()};
init(900,600);
})();
